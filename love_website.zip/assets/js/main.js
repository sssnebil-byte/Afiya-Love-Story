// --- Lightbox Functions ---

function openLightbox(imgSrc) {
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxCaption = document.getElementById('lightbox-caption');
    
    lightbox.style.display = "block";
    lightboxImg.src = imgSrc;
    
    // የፍቅር መልዕክት ለምስሉ
    lightboxCaption.innerHTML = "አንተ/አንቺ የኔ ዓለም ነሽ። እያንዳንዱ ቅጽበት ከሰዎች በላይ ነው! 💖"; 
    
    // ኦርጅናሉን alt text መጠቀም ከፈለጉ:
    // lightboxCaption.innerHTML = event.target.alt;
}

function closeLightbox() {
    document.getElementById('lightbox').style.display = "none";
}

// አንድ ጊዜ ጠቅ በማድረግም ለመዝጋት:
document.addEventListener('DOMContentLoaded', () => {
    const lightbox = document.getElementById('lightbox');
    if (lightbox) {
        lightbox.addEventListener('click', function(e) {
            // ምስሉን ወይም ቅርብ የሚለውን ቁልፍ ካልተጫነ ብቻ ዝጋ
            if (e.target === this || e.target.classList.contains('close-btn')) {
                closeLightbox();
            }
        });
    }
});
